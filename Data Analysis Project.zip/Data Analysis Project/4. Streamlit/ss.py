import streamlit as st
import pandas as pd


members = pd.read_csv("members.csv")
classes = pd.read_csv("classes.csv")
trainers = pd.read_csv("trainers.csv")
payments = pd.read_csv("payments.csv")
attendance = pd.read_csv("attendance.csv")


st.set_page_config(page_title="GYM Dashboard", layout="wide")
st.title("🏋️ GYM Data Dashboard")

# Sidebar navigation
st.sidebar.header("Navigation")
option = st.sidebar.radio("Select Report:", (
    "Membership Types",
    "Top 10 Yoga Attendees",
    "Top 5 Paying Members",
    "Classes per Trainer",
    "Attendance per Class",
    "Attendance per Trainer",
    "Top 10 Members by Attendance",
    "Revenue per Class",
    "Payments by Membership Type",
    "Attendance by Gender",
    "Attendance by Year",
    "Attendance by Age"
))



if option == "Membership Types":
    df = members.groupby("MembershipType").size().reset_index(name="TotalMembers")
    st.subheader("📊 Members by Membership Type")
    st.bar_chart(df.set_index("MembershipType"))
    st.dataframe(df)

elif option == "Top 10 Yoga Attendees":
    df = (attendance.merge(classes, on="ClassID")
                    .merge(members, on="MemberID"))
    df = (df[(df["ClassName"] == "Yoga") & (df["Status"] == "Present")]
            .groupby(["MemberID", "Name", "ClassName"])
            .size()
            .reset_index(name="TotalAtt")
            .sort_values("TotalAtt", ascending=False)
            .head(10))
    st.subheader("🧘 Top 10 Yoga Attendees")
    st.table(df)

elif option == "Top 5 Paying Members":
    df = (payments.merge(members, on="MemberID")
                   .groupby(["MemberID", "Name"])["Amount"]
                   .sum()
                   .reset_index(name="TotalPayments")
                   .sort_values("TotalPayments", ascending=False)
                   .head(5))
    st.subheader("💰 Top 5 Paying Members")
    st.bar_chart(df.set_index("Name")["TotalPayments"])
    st.dataframe(df)

elif option == "Classes per Trainer":
    df = (classes.merge(trainers, on="TrainerID", how="left")
                 .groupby("Name")
                 .size()
                 .reset_index(name="TotalClasses"))
    st.subheader("📚 Classes per Trainer")
    st.bar_chart(df.set_index("Name"))
    st.dataframe(df)

elif option == "Attendance per Class":
    df = (attendance[attendance["Status"] == "Present"]
            .merge(classes, on="ClassID")
            .groupby("ClassName")
            .size()
            .reset_index(name="TotalAttendance"))
    st.subheader("👥 Attendance per Class")
    st.bar_chart(df.set_index("ClassName"))
    st.dataframe(df)

elif option == "Attendance per Trainer":
    df = (attendance[attendance["Status"] == "Present"]
            .merge(classes, on="ClassID")
            .merge(trainers, on="TrainerID")
            .groupby("Name")
            .size()
            .reset_index(name="TotalAttendance")
            .sort_values("TotalAttendance", ascending=False))
    st.subheader("🏋️ Attendance per Trainer")
    st.bar_chart(df.set_index("Name"))
    st.dataframe(df)

elif option == "Top 10 Members by Attendance":
    df = (attendance[attendance["Status"] == "Present"]
            .merge(members, on="MemberID")
            .groupby(["MemberID", "Name"])
            .size()
            .reset_index(name="TotalNumberofAttendance")
            .sort_values("TotalNumberofAttendance", ascending=False)
            .head(10))
    st.subheader("🏆 Top 10 Members by Attendance")
    st.bar_chart(df.set_index("Name"))
    st.dataframe(df)

elif option == "Revenue per Class":
    df = (attendance.merge(classes, on="ClassID")
                    .merge(members, on="MemberID")
                    .merge(payments, on="MemberID")
                    .groupby(["ClassID", "ClassName"])["Amount"]
                    .sum()
                    .reset_index(name="TotalAmount"))
    st.subheader("💵 Revenue per Class")
    st.bar_chart(df.set_index("ClassName"))
    st.dataframe(df)

elif option == "Payments by Membership Type":
    df = (payments.merge(members, on="MemberID")
                   .groupby("MembershipType")["Amount"]
                   .sum()
                   .reset_index(name="TotalPayments")
                   .sort_values("TotalPayments", ascending=False))
    st.subheader("💳 Payments by Membership Type")
    st.bar_chart(df.set_index("MembershipType"))
    st.dataframe(df)

elif option == "Attendance by Gender":
    df = (attendance[attendance["Status"] == "Present"]
            .merge(members, on="MemberID")
            .groupby("Gender")
            .size()
            .reset_index(name="TotalAttendance"))
    st.subheader("🚻 Attendance by Gender")
    st.bar_chart(df.set_index("Gender"))
    st.dataframe(df)

elif option == "Attendance by Year":
    attendance["Year"] = pd.to_datetime(attendance["Date"]).dt.year
    df = (attendance[attendance["Status"] == "Present"]
            .groupby("Year")
            .size()
            .reset_index(name="TotalAttendance"))
    st.subheader("📅 Attendance by Year")
    st.line_chart(df.set_index("Year"))
    st.dataframe(df)

elif option == "Attendance by Age":
    df = (attendance[attendance["Status"] == "Present"]
            .merge(members, on="MemberID")
            .groupby("Age")
            .size()
            .reset_index(name="TotalAttendance"))
    st.subheader("🎂 Attendance by Age")
    st.line_chart(df.set_index("Age"))
    st.dataframe(df)
