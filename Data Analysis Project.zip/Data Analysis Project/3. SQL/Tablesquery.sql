use [GYM data_faker]


SELECT MembershipType, COUNT(*) AS TotalMembers
FROM Members
GROUP BY MembershipType;




SELECT top 10 m.MemberID,m.Name,c.ClassName,COUNT(*) AS TotalAtt
FROM classes c
JOIN attendance a ON a.ClassID = c.ClassID
JOIN members m ON m.MemberID = a.MemberID
WHERE c.ClassName = 'Yoga' AND a.Status = 'Present'
GROUP BY m.MemberID, m.Name, c.ClassName
ORDER BY TotalAtt DESC;



select top 5 m.MemberID,m.Name,sum(p.Amount) as TotalPayments
from members m
join payments p on p.MemberID=m.MemberID
group by m.MemberID,m.Name
order by TotalPayments desc;



select t.Name, count(*) as TotalClasses
from trainers t
left join classes c on c.TrainerID=t.TrainerID
group by t.TrainerID,t.Name;



select c.ClassName,count(*) as TotalAttendance
from classes c
join attendance a on a.ClassID=C.ClassID
where a.Status='Present'
Group by c.ClassName;



select t.TrainerID,t.Name,count(*) as TotalAttendance
from trainers t
join classes c on c.TrainerID=t.TrainerID
join attendance a on a.ClassID=c.ClassID
where a.Status='Present'
group by t.TrainerID,t.Name
order by TotalAttendance desc;



select top 10 m.MemberID,m.Name,count(*) as TotalNumberofAttendance
from members m 
left join attendance a on a.MemberID=m.MemberID
where a.Status='Present'
group by m.MemberID,m.Name
order by TotalNumberofAttendance desc;



select c.ClassID,c.ClassName,sum(p.Amount) as TotalAmount
from classes c
join attendance a on c.ClassID=a.ClassID
join members m on m.MemberID=a.MemberID
join payments p on p.MemberID=m.MemberID
group by c.ClassID,c.ClassName;



select sum(p.Amount) AS TotalPayments,m.MembershipType
from members m
join payments p on p.MemberID=m.MemberID
group by m.MembershipType
order by TotalPayments desc;



select m.Gender, count(*) as TotalAttendance
from members m
join attendance a on a.MemberID=m.MemberID
where a.Status='Present'
group by m.Gender;



select year(a.Date) as Year,count(*) as TotalAttendance
from attendance a
where a.Status='Present'
group by year(a.Date)
order by year(a.Date);



select m.Age,count(*) as TotalAttendance
from members m 
join attendance a on a.MemberID=m.MemberID
where a.Status='Present'
group by m.Age
order by m.Age;